import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * This class represents the home page of the application
 * @author Ashank Patel
 * @author Binhang Zhu
 */
public class HomePage implements ActionListener {

	// Frame for the home page
	Frame Home;

	// Number of buttons on the home page
	int numButtons = 3;

	// Static variables to store user information
	private static String username = "DefaultUser";
	private static String fontColor = "Black";
	private static String fontStyle = "Arial";

	// Settings manager to handle loading and saving settings
	SettingsManager settingsManager;


	/**
	 * Constructor: This method sets up the frame for the homepage.
	 */
	HomePage() {

		// Load settings from a file using the SettingsManager
		settingsManager = SettingsManager.loadSettingsFromFile();

		// Array of button texts for the menu
		String[] menuButtonTexts = {"Input file", "Settings", "Help"};

		// Create the main frame for the home page
		Home = new Frame(numButtons, menuButtonTexts, this);

		// Update UI based on user settings
		updateUIBasedOnSettings();
	}

	/**
	 * This Method updates UI elements based on user settings
	 */ 
	private void updateUIBasedOnSettings() {
		// Retrieve user settings from the settings manager
		fontColor = settingsManager.getFontColor();
		fontStyle = settingsManager.getFontStyle();
		username = settingsManager.getUserName();

		// Create a label to display a welcome message with user-specific formatting
		JLabel userText = new JLabel();
		userText.setText("<html><font size='30' color='" + fontColor + "' face='" + fontStyle + "'>Welcome " + username + "!</font></html>");
		userText.setHorizontalAlignment(JLabel.CENTER);

		// Add the label to the main panel of the home page
		Home.getMainPanel().add(userText, BorderLayout.CENTER);
	}
	/**
	 * ActionListener method handles button clicks
	 * @param e - clicking events
	 */ 
	// ActionListener method to handle button clicks
	@Override
	public void actionPerformed(ActionEvent e) {

		// Handle input file button click
		if (e.getSource() == Home.getMenu().getButton(0)) {
			System.out.println("button 1 clicked!");

			// Open a file chooser dialog to select an input file
			JFileChooser fileChooser = new JFileChooser();
			int response = fileChooser.showOpenDialog(null);

			// If a file is selected, create a new MainEditingPage with the selected file
			if (response == JFileChooser.APPROVE_OPTION) {
				File selectedFile = new File(fileChooser.getSelectedFile().getAbsolutePath());
				System.out.println(selectedFile);
				try {
					MainEditingPage newMainEditWindow = new MainEditingPage(selectedFile);
					Home.dispose();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
		// Handle settings button click
		else if (e.getSource() == Home.getMenu().getButton(1)) {
			System.out.println("button 2 clicked!");

			// Close the current home page and open the settings page
			Home.dispose();
			SettingsPage newWindow = new SettingsPage();
		}
		// Handle help button click
		else if (e.getSource() == Home.getMenu().getButton(2)) {
			System.out.println("button  3 clicked!");

			// Close the current home page and open the help page
			Home.dispose();
			HelpPage newWindow = new HelpPage();
		}
	}

	/**
	 * Getter for username
	 * @return the username
	 */ 
	public static String getUserName() {
		return username;
	}

	/**
	 * Setter for username
	 * @param newUserName - the username that we will use
	 */
	public static void setUserName(String newUserName) {
		username = newUserName;
	}

	/**
	 * Getter for font color
	 * @return the string representing the font color
	 */ 
	public String getFontColor() {
		return fontColor;
	}

	/**
	 * Setter for font color
	 * @param newFontColor - new color for font
	 */ 
	public static void setFontColor(String newFontColor) {
		fontColor = newFontColor;
	}

	/**
	 * Get the font style
	 * @return the font style
	 */ 
	public String getFontStyle() {
		return fontStyle;
	}

	/**
	 * Set the font style
	 * @param newFontStyle - new font for text
	 */
	public static void setFontStyle(String newFontStyle) {
		fontStyle = newFontStyle;
	}
}
