
public class Main {
	
	// temporarily contains the main function to start the program
	// may change later

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new HomePage();
	}

}
