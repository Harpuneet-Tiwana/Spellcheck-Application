import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
/**
 * The Menu class contains methods to access and create buttons within a menu panel.
 * This class is used as part of graphical user interfaces
 * 
 * @author Ashank Patel
 * @author Harpuneet Tiwana
 * @author Vivian Petrov
 * @author Dorty Makaloni
 * @author Binhang Zhu
 *
 */
public class Menu {
	
	JPanel menuPanel;
	Button[] buttonArray;
	FlowLayout layout;
	
	/**
	 * This constructor is the default constructor for the Menu class
	 */
	Menu(){
		menuPanel = new JPanel();
		menuPanel.setBackground(Color.lightGray);
		menuPanel.setPreferredSize(new Dimension(100,100));
		
	}
	/**
     * This constructor is used to initialize the Menu class with specified parameters.
     *
     * @param numButtons number of buttons to be added to Menu
     * @param buttonTexts array of strings representing the text for each button
     * @param e  ActionListener object to handle button events.
     */
	Menu(int numButtons, String[] buttonTexts, ActionListener e){
		
		// set up the panel for the menu (this is the container for the menu; everything goes in here)
		menuPanel = new JPanel();
		menuPanel.setBackground(Color.lightGray);
		menuPanel.setPreferredSize(new Dimension(100,100));
		
		// Set up the layout manager and adjust gaps between buttons
        layout = new FlowLayout(FlowLayout.CENTER, 20, 15);
        menuPanel.setLayout(layout);
		
        // create and add the appropriate buttons to the menu
	    buttonArray = new Button[numButtons];
		for (int i=0;i<numButtons;i++) {
			buttonArray[i] = this.addButton(buttonTexts[i], e);
		}
		
	}
	/**
     * This method return the JPanel object representing the menu
     *
     * @return menuPanel the JPanel object of the menu.
     */
	public JPanel getMenu() {
		return menuPanel;
	}
	/**
     * This method is used to create and add individual buttons to the menu
     *
     * @param buttonText text to be displayed on the button.
     * @param e ActionListener object to handle button events.
     * @return newButton the Button object representing the created button.
     */
	private Button addButton(String buttonText, ActionListener e) {
		Button newButton = new Button(buttonText, e);
		menuPanel.add(newButton.getButton());
		return newButton;
		
	}
	/**
     * This method returns the JButton object of a specific button in the menu
     *
     * @param buttonNum index of the button in the menu array
     * @return the JButton object of the specified button.
     */
	public JButton getButton(int buttonNum) {
		return buttonArray[buttonNum].getButton();
	}

}
