
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
/**
 * This class represents the error corrections page of the application
 * @author Ashank Patel
 */
public class ErrorCorrectionPage implements ActionListener{
	
	Frame Correction;
	int numButtons = 1;
	JTextArea textArea;
	OptionBar correctionBar;
	String[] errorStrings;
	int[] errorType;
	int errorCounter=0;
	ArrayList<Integer> highlightIndexTracker = new ArrayList<Integer>(); // store original indices of highlighter of textArea
	int actionHandle = 0;
	JTextField textField;
	String[] correctionOptions = {"previous","manual entry", "suggestions", "delete", "ignore once",
			"ignore always", "add word","next"};
	boolean suggestionClicked = false;
	Color[] errorColors;
	int[] errorLocIndex;
	int charOffset=0;
	boolean[] skippableError; // stores bool whether errors should be ignored
	String suggestionSelected="";
	ErrorCorrection errorCorrection;
	Dictionary dictionary;
	DocumentHandle documentHandle;
	
	
	/**
	 * Constructor: This method creates the page for error correction.
	 * @param detectionTextArea - the text area for the detection frame
	 * @param documentHandle - the DocumentHandle object
	 * @param errorColors - array of the three error colors
	 * @param dictionary - the Dictionary object
	 */
	ErrorCorrectionPage(JTextArea detectionTextArea, DocumentHandle documentHandle, Color[] errorColors, Dictionary dictionary){
		
		// define classes
		this.dictionary = dictionary;
		this.documentHandle = documentHandle;
		errorCorrection = new ErrorCorrection(documentHandle, dictionary);
		
		// set up menu and frame
		String [] menuButtonTexts = {"Done"};
		Correction = new Frame(numButtons, menuButtonTexts, this);
		
		// set up legend
		Legend detectionLegend = new Legend();
	    Correction.getMenu().getMenu().add(detectionLegend.getLegendPanel(), FlowLayout.LEFT);
	    Correction.getMenu().getMenu().setLayout(new FlowLayout(FlowLayout.LEADING, 20, 15));
	    
	    // get same text area object from error detection page
	    textArea = detectionTextArea;
	    
	    // Add the JTextArea to the mainPanel
	    Correction.getMainPanel().add(textArea, BorderLayout.CENTER);
	    
	    // store error information variables
	    this.errorLocIndex=documentHandle.getErrorLocIndex();
	    this.errorType = documentHandle.getErrorTypeIntArr();
	    this.errorColors = errorColors;
	    this.errorStrings = documentHandle.getErrorStrings();
	    
	    
	    // initialize highlightIndexTracker
	    for (int i=0; i<textArea.getHighlighter().getHighlights().length; i++) {
	    	highlightIndexTracker.add(i);
	    }
	    
	    // initialize skippableError
	    skippableError = new boolean[errorStrings.length];
	    for (int i=0; i<errorStrings.length; i++) {
	    	skippableError[i] = false;
	    }
	    
	    // set up the correction menu which contains the correction buttons and error display
		correctionBar = new OptionBar(errorStrings[errorCounter],8,correctionOptions, this, errorColors[errorCounter]);
		Correction.add(correctionBar.getOptionBar(),BorderLayout.SOUTH);
		
		
	}
	/**
	 * ActionListener method to handle button clicks
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// done button of frame clicked
		if (e.getSource()==Correction.getMenu().getButton(0)) {
			System.out.println("done button clicked!");
			Correction.dispose();
			MainEditingPage newWindow = new MainEditingPage(textArea.getText(), documentHandle);
		}
		// automatic ignore due to previous ignore always
		else if (skippableError[errorCounter] == true) {
			textArea.replaceRange(errorStrings[errorCounter], errorLocIndex[errorCounter] + charOffset, 
					   errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset);
			
			// already at last error
			if (errorCounter == errorStrings.length-1) {
				JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
			}
			// not at last error
			else if (errorCounter < errorStrings.length-1) {
				// update errorCounter to next and get its text
				errorCounter++;
				correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
			}
		}
		// if any main option buttons are clicked
		else if (actionHandle == 0) {
			// click previous
			if (e.getSource()==correctionBar.getButton(0)) {
				// if error is 2nd or more
				if (errorCounter > 0) {
					// update errorCounter to prev and get its text
					errorCounter--;
					correctionBar.changeErrorDisplay(errorStrings[errorCounter],errorColors[errorCounter]);
					// ------------- code here to either obtain fixed corrections OR ask for specific fix
					// 1st option is more convenient for you
					
					// potentially code here to change curr highlight
				}
				// if error is the first one -> display message
				else if (errorCounter == 0) {
					JOptionPane.showMessageDialog(Correction, "No previous error", null, JOptionPane.WARNING_MESSAGE);
				}
								
			}
			// click manual entry
			if (e.getSource()==correctionBar.getButton(1)) {
				System.out.println("manual entry clicked!");
				actionHandle=1;
				
				// remove buttons
				correctionBar.removeButtons();
			    
				// add submission box
				textField = new JTextField();
				textField.setPreferredSize(new Dimension(100,40));
				correctionBar.getOptionBar().add(textField);
				
				// add submission button
				String[] buttonNames = {"Enter", "Back"};
				correctionBar.addButtons(2, buttonNames, this);
								
			}
			// click suggestions
			else if (e.getSource() == correctionBar.getButton(2)) {
			    System.out.println("suggestions clicked!");
			    actionHandle=2;
			 
			    // obtain suggestions
			    ArrayList<String> suggestionWords = errorCorrection.fixMisspelling(errorStrings[errorCounter]);
			    String[] suggestionOptions = new String[5];
			    suggestionOptions[0] = "back";
			    suggestionOptions[1] = "done";
			    System.out.println("Suggestion Words length: " + suggestionWords.size());
			    
			    for (int i=2; i<5; i++) {
			    	 String suggestionWord = (suggestionWords.size() > (i-2)) ? suggestionWords.get(i-2) : "No Suggestion";
			    	 suggestionOptions[i] = suggestionWord;
			    }
			    // -------------------------------------------------------------------------------
			    
			    // remove buttons
			    correctionBar.removeButtons();
			    
			    
			    correctionBar.addButtons(5, suggestionOptions, this);

			}
			// click deletion
			else if (e.getSource()==correctionBar.getButton(3)) {
				System.out.println("delete clicked!");
				
				System.out.println("errorCounter after deletion: " + errorCounter);
				
				
				int startIndex = errorLocIndex[errorCounter] + charOffset;
				int endIndex = errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset;
				
				if ((startIndex>0)&&(textArea.getText().charAt(startIndex-1)== ' ')
						&&(endIndex<(textArea.getText().length()-1))&&(textArea.getText().charAt(endIndex+1)== ' ')) {
					textArea.replaceRange("", startIndex, endIndex+1);
					charOffset += (0 - errorStrings[errorCounter].length()-1);
					
				}
				else {
				
					textArea.replaceRange("", startIndex, endIndex);
					charOffset += (0 - errorStrings[errorCounter].length());
				}
				
				// automatically go to next error
				// already at last error
				if (errorCounter == errorStrings.length-1) {
					JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
				}
				// not at last error
				else if (errorCounter < errorStrings.length-1) {
					// update errorCounter to next and get its text
					errorCounter++;
					correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
				}
				// update correction counter				
				documentHandle.incrementCorrection(2);
				
			}
			// click ignore once
			
			else if (e.getSource()==correctionBar.getButton(4)) {
				System.out.println("ignore once clicked!");
				
				textArea.replaceRange(errorStrings[errorCounter], errorLocIndex[errorCounter] + charOffset, 
						   errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset);
				
				// already at last error
				if (errorCounter == errorStrings.length-1) {
					JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
				}
				// not at last error
				else if (errorCounter < errorStrings.length-1) {
					// update errorCounter to next and get its text
					errorCounter++;
					correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
				}
				
				// update correction counter				
				documentHandle.incrementCorrection(3);
			}
			// click ignore always
			else if (e.getSource()==correctionBar.getButton(5)) {
				System.out.println("ignore always clicked!");
				
				for (int i=errorCounter; i<errorStrings.length; i++) {
					if (errorStrings[i].equals(errorStrings[errorCounter])) {
						skippableError[i] = true;
						
						textArea.replaceRange(errorStrings[errorCounter], errorLocIndex[errorCounter] + charOffset, 
								   errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset);
						
					}
				}
				// already at last error
				if (errorCounter == errorStrings.length-1) {
					JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
				}
				// not at last error
				else if (errorCounter < errorStrings.length-1) {
					// update errorCounter to next and get its text
					errorCounter++;
					correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
				}
				
				
				
			}
			// click add word
			else if (e.getSource()==correctionBar.getButton(6)) {
				System.out.println("add word clicked!");
				actionHandle=6;
				
				
				// remove buttons
				correctionBar.removeButtons();
			    
				// add submission box
				textField = new JTextField();
				textField.setPreferredSize(new Dimension(100,40));
				correctionBar.getOptionBar().add(textField);
				
				// add submission button
				String[] buttonNames = {"Enter", "Back"};
				correctionBar.addButtons(2, buttonNames, this);
				
				
			}
			// click next
			else if (e.getSource()==correctionBar.getButton(7)) {
				// already at last error
				if (errorCounter == errorStrings.length-1) {
					JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
				}
				// not at last error
				else if (errorCounter < errorStrings.length-1) {
					// update errorCounter to next and get its text
					errorCounter++;
					correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
					
										
					if (skippableError[errorCounter] == true) {
						textArea.replaceRange(errorStrings[errorCounter], errorLocIndex[errorCounter] + charOffset, 
								   errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset);
						
						// already at last error
						if (errorCounter == errorStrings.length-1) {
							JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
						}
						// not at last error
						else if (errorCounter < errorStrings.length-1) {
							// update errorCounter to next and get its text
							errorCounter++;
							correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
						}
					}
				}
			}
		}
		
		// ==============================================================================
		// ==============================================================================
		// within ------------------------------------------------------------------
		
		// manual entry
		else if (actionHandle == 1) {
			
			// enter button
			if (e.getSource()==correctionBar.getButton(0)) {
				   // print out word that was manually entered
				   System.out.println("You have entered: " + textField.getText());
				   
				   // replace the error with the new string and update charOffset
				   textArea.replaceRange(textField.getText(), errorLocIndex[errorCounter] + charOffset, 
						   errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset);
				   charOffset += (textField.getText().length() - errorStrings[errorCounter].length());
				   // --------------------------------
				   // Note: after manual enters a word, they cannot go to a previous word and manually replace it --> will lead to undefined results
				   if (textField.getText().isBlank() == false){
					   int response = JOptionPane.showConfirmDialog(Correction, "Would you like to add this word to your dictionary", 
							   null, JOptionPane.YES_NO_OPTION);
					   
					   if (response == 0) {
						   System.out.println("word added to user dictionary");
						   
					   }
				   }
				   
				   // update correction counter
				   documentHandle.incrementCorrection(0);
				  // remove JTextfield for text input
				  correctionBar.getOptionBar().remove(textField);
				  // remove buttons
				  correctionBar.removeButtons();
				  // add original buttons
				  correctionBar.addButtons(8, correctionOptions, this);				
				  // renew actionHandle
				  actionHandle = 0;
				  // already at last error
				  if (errorCounter == errorStrings.length-1) {
						JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
				  }
				  // not at last error
				  else if (errorCounter < errorStrings.length-1) {
					// update errorCounter to next and get its text
						errorCounter++;
						correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
				  }
			}
			// back button
			else if (e.getSource()==correctionBar.getButton(1)){
				System.out.println("clicked back");	
				// remove JTextfield for text input
				correctionBar.getOptionBar().remove(textField);
				// remove buttons
				correctionBar.removeButtons();
				// add original buttons
				correctionBar.addButtons(8, correctionOptions, this);				
				// renew actionHandle
				actionHandle = 0;
			}
		}
		
		// suggestions
		else if (actionHandle == 2) {
			
			
			// back button
			if (e.getSource()==correctionBar.getButton(0)) {
				System.out.println("clicked back");	
				// remove buttons
			    correctionBar.removeButtons();
			    // add original buttons
			    correctionBar.addButtons(8, correctionOptions, this);
				// renew actionHandle
				actionHandle = 0;
			    
			}
			// confirm button
			else if (e.getSource()==correctionBar.getButton(1)) {
				System.out.println("clicked suggestion 2");
				if (suggestionClicked == false) {
					// ---------- code here to create pop up message potentially if no suggestions selected --------
					JOptionPane.showMessageDialog(Correction, "Please choose a suggested fix", null, JOptionPane.WARNING_MESSAGE);
				}
				else {
					textArea.replaceRange(suggestionSelected, errorLocIndex[errorCounter] + charOffset, 
						errorLocIndex[errorCounter] + errorStrings[errorCounter].length() + charOffset);
					charOffset += (suggestionSelected.length() - errorStrings[errorCounter].length());
					if (errorCounter == errorStrings.length-1) {
						JOptionPane.showMessageDialog(Correction, "No more errors", null, JOptionPane.WARNING_MESSAGE);
					}
					// not at last error
					else if (errorCounter < errorStrings.length-1) {
						// update errorCounter to next and get its text
						errorCounter++;
						correctionBar.changeErrorDisplay(errorStrings[errorCounter], errorColors[errorCounter]);
					}
					// update correction counter
					documentHandle.incrementCorrection(1);
					// remove buttons
				    correctionBar.removeButtons();
				    // add original buttons
				    correctionBar.addButtons(8, correctionOptions, this);
				    // renew suggestionClicked
				    suggestionClicked = false;
					// renew actionHandle
					actionHandle = 0;
				}
				
			}
			// suggestion 1
			else if (e.getSource()==correctionBar.getButton(2)) {
				System.out.println("clicked suggestion 3");
				//update suggestionClicked
				suggestionClicked = true;
				suggestionSelected=correctionBar.getButton(2).getText();
				System.out.println("suggestion clicked: " + suggestionSelected);
				
				
			}
			// suggestion 2
			else if (e.getSource()==correctionBar.getButton(3)) {
				System.out.println("clicked suggestion 4");
				//update suggestionClicked
				suggestionClicked = true;
				suggestionSelected=correctionBar.getButton(3).getText();
				System.out.println("suggestion clicked: " + suggestionSelected);
				
			}
			// suggestion 3
			else if (e.getSource()==correctionBar.getButton(4)) {
				System.out.println("clicked suggestion 4");
				//update suggestionClicked
				suggestionClicked = true;
				suggestionSelected=correctionBar.getButton(4).getText();
				System.out.println("suggestion clicked: " + suggestionSelected);
				
			}
			
	
		}
		// deletion
		else if (actionHandle == 3) {
			System.out.println("within deletion");
			JOptionPane.showMessageDialog(Correction, "Error has already been deleted", null, JOptionPane.WARNING_MESSAGE);
			actionHandle = 0;
		}
		// ignore once
		else if (actionHandle == 4) {
			textArea.getHighlighter().removeHighlight(textArea.getHighlighter().getHighlights()[errorCounter]);
	
		}
		// ignore always
		else if (actionHandle == 5) {
	
		}
		// add word
		else if (actionHandle == 6) {
			// enter button
			if (e.getSource()==correctionBar.getButton(0)) {
				   
				   // --------------------------------
				   if (textField.getText().isBlank() == false){
					   int response = JOptionPane.showConfirmDialog(Correction, "Would you like to add this word to your dictionary", 
							   null, JOptionPane.YES_NO_OPTION);
					   
					   if (response == 0) {
						   System.out.println("word added to user dictionary");
						  
						   dictionary.addWord(textField.getText());
						   System.out.println("word added to user dictionary");
						   // update correction counter
						   documentHandle.incrementCorrection(5);
					   }
				   }
				  
			}
			// back button
			else if (e.getSource()==correctionBar.getButton(1)){
				System.out.println("clicked back");	
				// remove JTextfield for text input
				correctionBar.getOptionBar().remove(textField);
				// remove buttons
				correctionBar.removeButtons();
				// add original buttons
				correctionBar.addButtons(8, correctionOptions, this);				
				// renew actionHandle
				actionHandle = 0;
			}
			
		}
		

		
		
	
	}
}
