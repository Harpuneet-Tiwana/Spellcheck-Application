import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

// Class to represent the Settings page
public class SettingsPage implements ActionListener {

    // Frame for the settings page
    Frame Settings;

    // Number of buttons on the settings page
    int numButtons = 3;

    // Labels for different settings
    private JLabel fontSizeLabel, fontStyleLabel, fontColorLabel, usernameLabel;

    // Buttons to adjust font size
    private JButton minusButton, plusButton;

    // Text fields for user input
    private JTextField fontSizeTextField, usernameTextField;

    // Dropdowns for font style and color
    private JComboBox<String> fontStyleComboBox, fontColorComboBox;

    // Panel for organizing font size components
    private JPanel fontSizePanel;

    // Variables to store current settings
    int fontSize;
    String fontColor, fontStyle, user;

    // Settings manager to handle loading and saving settings
    SettingsManager settingsManager;

    // Constructor for the SettingsPage class
    SettingsPage() {

        // Load settings from a file using the SettingsManager
        settingsManager = SettingsManager.loadSettingsFromFile();

        // Array of button texts for the menu
        String[] menuButtonTexts = {"Back", "Save changes", "Reset"};

        // Create the main frame for the settings page
        Settings = new Frame(numButtons, menuButtonTexts, this);

        // Initialize components for font size settings
        fontSizeLabel = new JLabel("Font Size:");
        minusButton = new JButton("-");
        minusButton.setPreferredSize(new Dimension(100, 100));
        minusButton.addActionListener(this);
        fontSizeTextField = new JTextField(String.valueOf(4));
        fontSizeTextField.setEditable(false);
        fontSizeTextField.setHorizontalAlignment(JTextField.CENTER);
        fontSizeTextField.setPreferredSize(new Dimension(100, 100));
        fontSizeTextField.setText(String.valueOf(settingsManager.getFontSize()));
        plusButton = new JButton("+");
        plusButton.setPreferredSize(new Dimension(100, 100));
        plusButton.addActionListener(this);

        // Create a panel to organize font size components
        fontSizePanel = new JPanel();
        fontSizePanel.add(minusButton);
        fontSizePanel.add(fontSizeTextField);
        fontSizePanel.add(plusButton);

        // Initialize components for font style settings
        fontStyleLabel = new JLabel("Font Style:");
        fontStyleComboBox = new JComboBox<>(new String[]{"Arial", "Times New Roman", "Comic Sans MS", "Georgia"});
        fontStyleComboBox.setSelectedItem(settingsManager.getFontStyle());
        fontStyleComboBox.addActionListener(this);

        // Initialize components for font color settings
        fontColorLabel = new JLabel("Font Color:");
        fontColorComboBox = new JComboBox<>(new String[]{"Black", "Red", "Gray", "Blue"});
        fontColorComboBox.setSelectedItem(settingsManager.getFontColor());
        fontColorComboBox.addActionListener(this);

        // Initialize components for username settings
        usernameLabel = new JLabel("Username:");
        usernameTextField = new JTextField(user);
        usernameTextField.setText(settingsManager.getUserName());

        // Create a panel to organize all settings components
        JPanel panel = new JPanel(new GridLayout(4, 2, 0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add components to the panel
        panel.add(fontSizeLabel);
        panel.add(fontSizePanel);
        panel.add(fontStyleLabel);
        panel.add(fontStyleComboBox);
        panel.add(fontColorLabel);
        panel.add(fontColorComboBox);
        panel.add(usernameLabel);
        panel.add(usernameTextField);

        // Add the panel to the main frame
        Settings.add(panel);

    }

    // ActionListener method to handle button clicks
    @Override
    public void actionPerformed(ActionEvent e) {

        // Handle back button click
        if (e.getSource() == Settings.getMenu().getButton(0)) {
            System.out.println("back button clicked!");
            Settings.dispose();

            // Open a new HomePage
            HomePage newWindow = new HomePage();
        }
        // Handle save changes button click
        else if (e.getSource() == Settings.getMenu().getButton(1)) {
            System.out.println("button 2 clicked!");

            // Get username from the text field
            user = usernameTextField.getText();
            usernameTextField.setText(user);

            // Update settingsManager with new values
            settingsManager.setUserName(user);
            settingsManager.setFontSize(fontSize);
            settingsManager.setFontColor(fontColor);
            settingsManager.setFontStyle(fontStyle);

            // Save settings to a file
            settingsManager.saveSettingsToFile();

            // Update settings in HomePage and HelpPage
            HomePage.setUserName(user);
            HomePage.setFontStyle(fontStyle);
            HomePage.setFontColor(fontColor);
            HelpPage.setFontSize(fontSize);
            HelpPage.setFontColor(fontColor);
            HelpPage.setFontStyle(fontStyle);

        }
        // Handle reset button click
        else if (e.getSource() == Settings.getMenu().getButton(2)) {
            System.out.println("button  3 clicked!");

            // Reset username, font size, font style, and font color to default values
            usernameTextField.setText("DefaultUser");
            fontSizeTextField.setText("4");
            fontStyleComboBox.setSelectedItem("Arial");
            fontColorComboBox.setSelectedItem("Black");
        }
        // Handle minus button click
        else if (e.getSource() == minusButton) {
            decrementFontSize();
        }
        // Handle plus button click
        else if (e.getSource() == plusButton) {
            incrementFontSize();
        }
        // Handle font color dropdown selection
        else if (e.getSource() == fontColorComboBox) {
            String selectedColor = (String) fontColorComboBox.getSelectedItem();
            updateTextColor(selectedColor);
        }
        // Handle font style dropdown selection
        else if (e.getSource() == fontStyleComboBox) {
            String selectedFont = (String) fontStyleComboBox.getSelectedItem();
            changeFontStyle(selectedFont);
        }
    }

    // Method to decrement font size
    private void decrementFontSize() {
        fontSize = Integer.parseInt(fontSizeTextField.getText());
        if (fontSize > 1) {
            fontSize--;
            fontSizeTextField.setText(String.valueOf(fontSize));
        }
    }

    // Method to increment font size
    private void incrementFontSize() {
        fontSize = Integer.parseInt(fontSizeTextField.getText());
        fontSize++;
        fontSizeTextField.setText(String.valueOf(fontSize));
    }

    // Method to update text color based on dropdown selection
    private void updateTextColor(String selectedColor) {
        // Convert the selected color string to Color
        fontColor = switch (selectedColor) {
            case "Red" -> "Red";
            case "Gray" -> "Gray";
            case "Blue" -> "Blue";
            default -> "Black";
        };
    }

    // Method to change font style based on dropdown selection
    private void changeFontStyle(String selectedFont) {
        fontStyle = switch (selectedFont) {
            case "Times New Roman" -> "Times New Roman";
            case "Comic Sans MS" -> "Comic Sans MS";
            case "Georgia" -> "Georgia";
            default -> "Arial";
        };
    }
}
