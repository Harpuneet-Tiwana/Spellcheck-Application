
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
/**
 * The
 * @author Ashank Patel
 */
public class ErrorDetectionPage implements ActionListener{
	
	Frame Detection;
	int numButtons = 2;
	JTextArea textArea;
	DocumentHandle documentHandle;
	Color[] errorColors;
	ErrorDetection errorDetection;
	Dictionary dictionary;
	/**
	 * This method creates the page for error detection
	 * @param documentHandle - the DocumentHandle object
	 * @param text
	 */
	ErrorDetectionPage(DocumentHandle documentHandle, String text){
		
		// obtain documentHandle object from before
		this.documentHandle = documentHandle;
		errorDetection = new ErrorDetection(documentHandle, text);
		dictionary = new Dictionary();
		
		//------------------------------ Call ErrorDetection to check all the errors ---------------------
		errorDetection.checkSpelling();
		
		// set up frame and menu for this page
		String [] menuButtonTexts = {"Correct Errors", "Done"};
		Detection = new Frame(numButtons, menuButtonTexts, this);
		
		// set up text area for this page
		textArea = new JTextArea();
		textArea.setText(text);
        textArea.setLineWrap(true);  // Enable line wrap
        textArea.setWrapStyleWord(true);
        
        // get error info from documentHandle and pass it all to highlightWords func to highlight those errors		
		highlightWords(textArea, documentHandle.getErrorStrings(), documentHandle.getErrorTypeIntArr(), 
				documentHandle.getErrorLocIndex());
		
		// Set the JTextArea to be non-editable and set background color
        textArea.setEditable(false);
        textArea.setBackground(Color.cyan);
       
       // Add the JTextArea to the mainPanel of this frame
       Detection.getMainPanel().add(textArea, BorderLayout.CENTER);
       
       // create and add legend to the menu
       Legend detectionLegend = new Legend();
       Detection.getMenu().getMenu().add(detectionLegend.getLegendPanel(), FlowLayout.LEFT);
       Detection.getMenu().getMenu().setLayout(new FlowLayout(FlowLayout.LEADING, 20, 15));
       
		
	}
	/**
	 * This method helps to highlight words marked incorrect
	 * @param textArea
	 * @param errorStrings
	 * @param errorType - array of counts of error type
	 * @param errorLocIndex - 
	 */
	private void highlightWords(JTextArea textArea, String[] errorStrings, int[] errorType, int[] errorLocIndex) {
		SwingUtilities.invokeLater(() -> {
			
			// define errorColors array- will store colors used so that errorCorrectionPage can use it
			errorColors = new Color[errorStrings.length];
			
			// define highlighter object
            Highlighter highlighter = textArea.getHighlighter();
            
            // set up variable that will be used to help highlight the correct words
            String wordToHighlight;
            int index = 0;
            Color c = Color.black;
            
            // for all errors, highlight the correct words in the text area
            for (int i=0; i<errorStrings.length; i++) {
            	
            	wordToHighlight = errorStrings[i];
            	index = errorLocIndex[i];
            	
            	// commented out section is for mouse detection (may never do as method is deprecated
            	/*
            	try {
					System.out.println(textArea.modelToView(index));
				} catch (BadLocationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	*/
            	
            	// determine correct error color based on error type
            	if (errorType[i] == 0) {
            		c = Color.red;
            	}
            	else if (errorType[i] == 1) {
            		c = Color.orange;
            	}
            	else if (errorType[i] == 2) {
            		c = Color.yellow;
            	}
                
            	// update errorColors array
            	errorColors[i] = c;
            	
            	// highlight the specific word
            	try {
					highlighter.addHighlight(index, index + wordToHighlight.length(),
					        new DefaultHighlighter.DefaultHighlightPainter(c));
					
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	
            }            
        });
	}
	/**
	 * Getter method for the JTextArea object of text area
	 * @return the JTextArea object
	 */
	
	public JTextArea getTextArea() {
		return textArea;
	}
	/**
	 * Getter method for the array of the colors
	 * @return the array of colors
	 */
	public Color[] getErrorColors() {
		return errorColors;
	}
	/**
	 * ActionListener method to handle button clicks
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// correct errors button
		if (e.getSource()==Detection.getMenu().getButton(0)) {
			System.out.println("correct errors button clicked!");
			Detection.dispose();
			ErrorCorrectionPage newWindow = new ErrorCorrectionPage(textArea, documentHandle, errorColors, dictionary);
		}
		// done button
		else if (e.getSource()==Detection.getMenu().getButton(1)) {
			System.out.println("done button clicked!");
			Detection.dispose();
			MainEditingPage newWindow = new MainEditingPage(textArea.getText(), documentHandle);;
		}
	
	}
	
}
