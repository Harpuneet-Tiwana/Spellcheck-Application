import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * This class will be the blueprint of the frame used for the pages.
 * @author Ashank Patel
 */
public class Frame extends JFrame{
	
	Menu menuBar;
	int numButtons;
	int buttonClicked;
	JPanel mainPanel;
	
	// default constructor for Frame --> may be able to delete it as it may be never used
	/**
	 * Constructor: This method creates the frame with its default formatting
	 */
	Frame(){
		this.setTitle("SpellCheck"); // sets title
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //when close is pressed
		this.setResizable(true); // prevent resizing
		this.setSize(600,400); // set dimensions
		this.setLayout(new BorderLayout(0,10));
		
		
		ImageIcon image = new ImageIcon("checkmark.png"); //create ImageIcon
		this.setIconImage(image.getImage()); // change icon of this
		this.getContentPane().setBackground(new Color(0,0,0)); // change background color

		this.setVisible(true); // make this visible
	}
	
	/**
	 * Constructor: This method creates the frame with its default formatting
	 * @param numMenuButtons
	 * @param menuButtonTexts
	 * @param e
	 */
	Frame(int numMenuButtons, String[] menuButtonTexts, ActionListener e){
		
		// set up the Frame
		this.setTitle("SpellCheck"); // sets title
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //when close is pressed
		this.setResizable(true); // prevent resizing
		this.setSize(1200,675); // set dimensions
		this.setLayout(new BorderLayout(0,30)); // frame's organization layout
		
		// set up the logo for the program
		// PROBLEM = does not work right now; needs to be fixed for later
		ImageIcon image = new ImageIcon("checkmark.png"); //create ImageIcon
		this.setIconImage(image.getImage()); // change icon of this
		this.getContentPane().setBackground(new Color(255,255,255)); // change background color
		
		// set up central panel for the frame (where document text goes)
		mainPanel = new JPanel();
		mainPanel.setBackground(new Color(0,255,255));		
		mainPanel.setLayout(new BorderLayout());
		this.add(mainPanel,BorderLayout.CENTER);
		
		// set up menu for the frame
		menuBar = new Menu(numMenuButtons,menuButtonTexts, e);
		this.add(menuBar.getMenu(), BorderLayout.NORTH);
		numButtons = numMenuButtons;
		
		// set up left and right side panels
		JPanel leftPanel = new JPanel();
		JPanel rightPanel = new JPanel();
		
		leftPanel.setBackground(new Color(25,0,30));
		rightPanel.setBackground(new Color(25,0,30));
		
		leftPanel.setPreferredSize(new Dimension(100, 200));
		rightPanel.setPreferredSize(new Dimension(100, 200));

		this.add(leftPanel, BorderLayout.WEST);
		this.add(rightPanel, BorderLayout.EAST);
		
		// make frame visible
		this.setVisible(true); // make this visible
	}
	/**
	 * Getter method for the Menu object
	 * @return Menu Object
	 */
	public Menu getMenu() {
		return menuBar;
	}
	/**
	 * Getter method for the frame
	 * @return the frame
	 */
	public JFrame getFrame() {
		return this;
	}
	
	/**
	 * Getter method for the main panel of the frame
	 * @return the main panel of the frame
	 */
	public JPanel getMainPanel() {
		return mainPanel;
	}

}
