import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * This class manages the document that will be
 * checked for spelling.
 * @author Harpuneet Tiwana
 * @author Vivian Petrov
 * @author Ashank Patel
 */
public class DocumentHandle {

    private ArrayList<String> documentWords = new ArrayList<>();
    private ArrayList<Integer> documentIndex = new ArrayList<>(); // contains char indices of all document words
    //static File file;
    private int lineCount = 0;
    private ArrayList<Integer> errorIndex = new ArrayList<Integer>(); // Array List to keep track of indices where errors were found
    int[] errorCount = new int[3]; // array to store the frequency of each type of error
    private ArrayList<Integer> errorType = new ArrayList<Integer>(); // Array List to keep track of the types of errors found
    int[] correctionCount = new int[6]; // array to store the frequency of each type of correction
    StringBuilder fileContent;
//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method reads file that user has selected.
     * Then adds each word from the document into the documentWords ArrayList.
     * Also copies the file's contents into the application's.
     * This method is static, so it can be accessed by the MyFrame class.
     * Void return because it does not actually return the ArrayList, just adds the words.
     * @throws IOException
     */
    public String readFile(File file) throws IOException {
    	
    	fileContent = new StringBuilder(); // used to copy the file contents to the text area

                BufferedReader reader = new BufferedReader(new FileReader(file)); // initialize the reader

                String line;
                while ((line = reader.readLine()) != null) {

                    lineCount++;

                    fileContent.append(line); // add each line as is to the fileContent StringBuilder
                    fileContent.append('\n'); // add a new line in the proper places
                    
                    String[] words = line.split("\\s+"); // spilt the line by spaces (words)

                    // add each word to documentWords
                    //documentWords.addAll(Arrays.asList(words));
                    for (String word : words) {

                        // remove leading and trailing non-alphabetic characters
                        String cleanWord = word.replaceAll("^[^a-zA-Z']+|[^a-zA-Z']+$", "");

                        if (!cleanWord.isEmpty()) {
                            documentWords.add(cleanWord); // add only non-empty cleaned words to the list
                        }

                    }
                    

                }
                reader.close(); // close the reader after complete
                
              
                
                documentIndexBuilder();
            	
                return fileContent.toString(); // display file contents in text area

        }
       

    /**
     * This method initializes the new documentHandle object when user is done with correcting errors.
     * @param newText - text String with the updated set of words for the document 
     */
    public void updateDocumentWords(String newText) {
    	
    	String[] words = newText.split("\\s+"); // spilt the line by spaces (words)
    	
        
    	fileContent = new StringBuilder();
    	fileContent.append(newText);
    	

    
    	for (String word : words) {

            // remove leading and trailing non-alphabetic characters
            String cleanWord = word.replaceAll("^[^a-zA-Z']+|[^a-zA-Z']+$", "");

            if (!cleanWord.isEmpty()) {
                documentWords.add(cleanWord); // add only non-empty cleaned words to the list
            }

        }
    	
    	documentIndexBuilder();
    	
    	
    }
    
    

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method exports the user's updated file with all corrections.
     * @throws IOException
     */
    public void writeFile(File file, String text) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(text); // writes text from textbox back to the file
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the word in the user's file that corresponds to the inputted index.
     * @param index is the index of the word in the ArrayList we want to access.
     * @return the proper word at the given index.
     */
    public String searchWord(int index) {
        return documentWords.get(index);
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method inputs error information into errorIndex and errorType
     * @param index of the error
     * @param type of error
     */
    public void enterError(int index, int type) {

        errorIndex.add(index); // append new index to errorIndex arrayList

        errorType.add(type); // append error type to errorType arrayList

        incrementErrors(type); // update errorCount by calling incrementErrors method

    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method replaces an incorrect word in user file with the correct word; can also be used to delete a word
     * @param index of the word in documentWords needed to be corrected/deleted
     * @param correctWord is the word replacing incorrect word
     */
    public void fixWord(int index, String correctWord) {

        // use built-in iterator set() for arrayList
        documentWords.set(index, correctWord); // finds element at index and replaces it with correctWord

    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the errorType int array.
     *
     * @return errorType
     */
    public ArrayList<Integer> getErrorType() {
        return errorType;
    }
    
    public int[] getErrorTypeIntArr() {
    	
    	int length = errorIndex.size();
        int[] errorTypeIntArr = new int[length];
        
        for (int i=0; i<length; i++) {
        	errorTypeIntArr[i] = errorType.get(i);
        }
        
        return errorTypeIntArr;
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the errorIndex int array.
     *
     * @return errorIndex
     */
    public ArrayList<Integer> getErrorIndex() {
        return errorIndex;
    }
    
    public String[] getErrorStrings() {
    	
    	int length = errorIndex.size();
        String[] errorStrings = new String[length];
        
        for (int i=0; i<length; i++) {
        	errorStrings[i] = searchWord(errorIndex.get(i));
        	
        }
        
        return errorStrings;
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the number of characters in the user's file.
     * @return totalCharacters
     */
    public int countNumChars() {
        int totalCharacters = 0;

        for (String word : documentWords) {
            totalCharacters += word.length();
        }

        return totalCharacters;
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the number of lines in the user's file.
     * @return lineCount
     */
    public int countNumLines() {
        return lineCount+1;
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the number of words in the user's file.
     * @return documentWords.size()
     */
    public int countNumWords() {
        return documentWords.size();
    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method increments value for the specific error type in errorCount
     * @param type of error
     */
    public void incrementErrors(int type) {

        for (int i = 0; i < errorCount.length; i++) {
            if (type == i) { // match type to errorCount index
                errorCount[i]++; // increment element at index i
            }
        }

    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method increments value for the specific correction type in correctionCount
     * @param type of correction
     */
    public void incrementCorrection(int type) {

        for (int i = 0; i < correctionCount.length; i++) {
            if (type == i) { // if type matches correctionCount index
                correctionCount[i]++; // increment element at index i
            }
        }

    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the frequency of a specific error type
     * @param type of error
     * @return numErrors  the frequency of that specific error type
     */
    public int getNumErrors(int type) {

        int numErrors = 0;

        for (int i = 0; i < errorCount.length; i++) { // find corresponding index to the error type
            if (type == i) {
                numErrors = errorCount[i]; // get frequency of the error type
            }
        }

        return numErrors;

    }

//---------------------------------------------------------------------------------------------------------------------

    /**
     * This method returns the frequency of a specific correction type
     * @param type of correction
     * @return numCorrections  the frequency of the correction type
     */
    public int getNumCorrections(int type) {

        int numCorrections = 0;

        for (int i = 0; i < correctionCount.length; i++) { // find corresponding index to the correction type
            if (type == i) {
                numCorrections = correctionCount[i]; // get frequency of the correction type
            }
        }

        return numCorrections;

    }
    /**
     * Getter method for the list of words in the document.
     * @return the list of words in the document
     */
    public ArrayList<String> getWords(){
    	return documentWords;
    }

//---------------------------------------------------------------------------------------------------------------------
    /**
     *  This method, supplies highlight feature use char indices for text area in errorDetection and errorCorrection.
     */
    public void documentIndexBuilder() {
    	String text = fileContent.toString();
    	int counter = 0;

    	
    	for (String word : documentWords) {

    		counter = text.indexOf(word, counter);
    		    		
    		documentIndex.add(counter);
    		counter=counter+word.length()+1;
    	}
    	
    }
    /**
     * This method provides the document index integer array.
     * @return integer array of indices
     */
    public int[] getDocumentIndex() {
    	int[] documentIndexIntArr = new int[documentIndex.size()];
    	for (int i=0; i < documentIndex.size(); i++) {
    		documentIndexIntArr[i] = documentIndex.get(i);
    	}
    	
    	return documentIndexIntArr;
    }
    
    /**
     * This method creates and returns the array that contains char indices of all the errors.
     * @return char indices array
     */
    public int[] getErrorLocIndex() {
    	int[] errorLocIndex = new int[errorIndex.size()];
    	for (int i=0; i<errorIndex.size();i++) {
    		errorLocIndex[i] = documentIndex.get(errorIndex.get(i));
    	}
    	
    	return errorLocIndex;
    }
    
}