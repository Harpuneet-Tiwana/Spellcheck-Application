/**
 * This class detects the errors in the document.
 * @author Harpuneet Tiwana
 * @author Vivian Petrov
 */ 
public class ErrorDetection {
        private Dictionary dict; // call Dictionary class
        private DocumentHandle documentHandle;
        String displayText;
        int counter=0;
        /**
    	 * This method makes an instance of Dictionary and provides the DocumentHandle object
    	 * @param documentHandle - the DocumentHandle object
    	 */
        public ErrorDetection(DocumentHandle documentHandle, String displayText) {
            dict = new Dictionary(); // create new Dictionary object
//            dict.initializeDict(); // initialize dictionary
            this.documentHandle = documentHandle;
            this.displayText = displayText;
        }
        /**
    	 * This method checks the spelling of the words in the document and
    	 * finds the errors in the file.
    	 * @return true if there is at least one error, false otherwise
    	 */
        public boolean checkSpelling() {

            int misspelling = 0;
            int cap = 0;
            int dupe = 0;

            for (int i = 0; i < documentHandle.countNumWords(); i++) { // go through words in documentWords
                String word = documentHandle.searchWord(i);
                
                String nextWord;
                if (i <= documentHandle.countNumWords()-2) {
                	nextWord = documentHandle.searchWord(i+1);
                }
                else {
                	nextWord = "";
                }
                
                if (checkMisspelling(word)==false) {
                    misspelling++;
                    documentHandle.enterError(i, 0);
                }
                else if (checkCapitalization(word)) {
                    cap++;
                    documentHandle.enterError(i, 1);
                }
                else if (checkDuplicate(word, nextWord)) {
                    dupe++;
                    documentHandle.enterError(i, 2);
                    System.out.println("A duplicate was entered");
                }
                counter++;
            }

            if (misspelling > 0 || cap > 0 || dupe > 0) { // if any errors were found
                return true;
            }

            return false;
        }

        /**
    	 * Helper method: This method checks if the word is misspelled.
    	 * @param query - the word to check
    	 * @return true if the word is incorrectly spelled, false otherwise
    	 */
        private boolean checkMisspelling(String query) {

            // go through dictionary and see if words match
            // if words don't match, return true

            return dict.searchWord(query.toLowerCase());


        }
        /**
    	 * Helper method: This method checks if the word is miscapitalized.
    	 * @param query - the word to check
    	 * @return true if the cord is incorrectly capitalized or non-capitalized, false otherwise
    	 */
        private boolean checkCapitalization(String query) {
        	
            boolean noCap = dict.searchWord(query.toLowerCase()); // check if word matches words in dictionary and ignore capitalizations
            boolean cap = dict.searchWord(query);

            if (noCap && !cap) { // if query matches a word in dict when ignoring cap is true but query does not match word in dict with cap
                	           	
            		int[] documentIndex = documentHandle.getDocumentIndex();
            		int wordChrIndex = documentIndex[counter];
            		if ((wordChrIndex>=2) && (displayText.charAt(wordChrIndex-2) == '.')) {
            			return false;
            		}         		
            		else {
            			return true;
            		}
            	
            	
            }
            return false;  // otherwise return false
        }
        /**
    	 * Helper method: This method checks if the checked word
    	 * and the word after it are the same.
    	 * @param query - the word to check
    	 * @param nextWord - word that follows the query word
    	 * @return true if words are the same, false otherwise
    	 */
        private boolean checkDuplicate(String query, String nextWord) {


            // check if word after query is the same
        	System.out.println("String query is: " + query);
        	System.out.println("String nextWord is: " + nextWord);
        	if (query.equals(nextWord)) { // if 2 words are the same, return true
                return true;
            }

            return false; // otherwise return false
        }

    }
