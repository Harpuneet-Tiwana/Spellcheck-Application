import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

/**
 * The MetricsPage class represents a user interface that displays a document's metrics
 * 
 * @author Ashank Patel
 * @author Harpuneet Tiwana
 * @author Vivian Petrov
 * @author Dorty Makaloni
 * @author Binhang Zhu
 *
 */
// Class representing the metrics page of the application
public class MetricsPage implements ActionListener {

	// Frame for the metrics page
	Frame Metrics;

	// Number of buttons on the metrics page
	int numButtons = 1;

	// Static variables for font settings
	private static int fontSize = 4;
	private static String fontColor = "Black";
	private static String fontStyle = "Arial";

	// Settings manager to handle loading and saving settings
	SettingsManager settingsManager;
	
	// Document Handle
	DocumentHandle documentHandle;
	String text;
	/**
     * This method initializes a new MetricsPage for a given document.
     *
     * @param documentHandle The DocumentHandle for the document to analyze.
     */
	// Constructor for the MetricsPage class
	MetricsPage(DocumentHandle documentHandle, String text) {

		// Load settings from a file using the SettingsManager
		settingsManager = SettingsManager.loadSettingsFromFile();

		this.documentHandle = documentHandle;
		this.text = text;
		
		// Array of button texts for the menu
		String[] menuButtonTexts = {"Back"};

		// Create the main frame for the metrics page
		Metrics = new Frame(numButtons, menuButtonTexts, this);
		Metrics.setResizable(false);

		// Update UI based on user settings
		updateUIBasedOnSettings();
	}
	/**
     * This method updates the UI elements based on user settings
     * 
     */
	// Method to update UI elements based on user settings
	private void updateUIBasedOnSettings() {
		// Retrieve user settings from the settings manager
				fontSize = settingsManager.getFontSize();
				fontStyle = settingsManager.getFontStyle();
				fontColor = settingsManager.getFontColor();

				// Add labels of the statistics names and their units
				JLabel stats = new JLabel();
				stats.setText("<html><font size='" + fontSize + "' color='" + fontColor + "' face='" + fontStyle
						+ "'>Characters:<br/>Lines:<br/>Words:<br/><br/>"
						+ "Misspellings:<br/>Wrong Capitalization:<br/>Double Words:<br/><br/>"
						+ "Manual Entries:<br/>Accepted Suggestions:<br/>Words Deleted:<br/>Ignore Once:<br/>Ignore Always:<br/>Words Added:</font></html>");

				JLabel units = new JLabel();
				units.setText("<html><font size='" + fontSize + "' color='" + fontColor + "' face='" + fontStyle + "'>"
						+ documentHandle.countNumChars() + "<br/>" + documentHandle.countNumLines() + "<br/>" + documentHandle.countNumWords() + "<br/><br/>"
						+ documentHandle.getNumErrors(0) + "<br/>" + documentHandle.getNumErrors(1) + "<br/>" + documentHandle.getNumErrors(2) + "<br/><br/>"
						+ documentHandle.getNumCorrections(0) + "<br/>" + documentHandle.getNumCorrections(1) + "<br/>" +documentHandle.getNumCorrections(2)
						+ "<br/>" +documentHandle.getNumCorrections(3) + "<br/>" + documentHandle.getNumCorrections(4) + "<br/>" + documentHandle.getNumCorrections(5) + "</font></html>");

				// The statistics' names are aligned to the left and the units are aligned to the right
				stats.setHorizontalAlignment(JLabel.LEFT);
				units.setHorizontalAlignment(JLabel.RIGHT);

				// Add the labels to the main panel of the metrics page
				Metrics.getMainPanel().add(stats, BorderLayout.WEST);
				Metrics.getMainPanel().add(units, BorderLayout.EAST);
	}
	/**
	* This method handles actions performed on the buttons of the Main Editing Page and performs corresponding actions
	* @param e an ActionEvent that represents an action done by the user
	*/
	// ActionListener method to handle button clicks
	@Override
	public void actionPerformed(ActionEvent e) {
		// Handle back button click
		if (e.getSource() == Metrics.getMenu().getButton(0)) {

			// Close the current metrics page and open the main editing page
			Metrics.dispose();
			MainEditingPage newWindow = new MainEditingPage(text, documentHandle);
		}
	}

	/**
     * This method returns the font size setting.
     *
     * @return fontSize current font size setting.
     */
	// Getter for font size
	public static int getFontSize() {
		return fontSize;
	}
	/**
     * This method sets the font size setting.
     *
     * @param fontSize  the fontSize to be set
     */
	// Setter for font size
	public static void setFontSize(int newFontSize) {
		fontSize = newFontSize;
	}
	/**
     * This method returns the font colour setting.
     *
     * @return fontColor current font color setting.
     */
	// Getter for font color
	public static String getFontColor() {
		return fontColor;
	}
	/**
     * This method returns the font colour setting.
     *
     * @return fontColor current font color setting.
     */
	// Setter for font color
	public static void setFontColor(String newFontColor) {
		fontColor = newFontColor;
	}


	/**
     * This method returns the font style setting.
     *
     * @return fontStyle current font style setting.
     */
	public static String getFontStyle() {
		return fontStyle;
	}

	/**
     * This method sets the font style setting.
     *
     * @return fontStyle current font style setting.
     */
	public static void setFontStyle(String newFontStyle) {
		fontStyle = newFontStyle;
	}
}
