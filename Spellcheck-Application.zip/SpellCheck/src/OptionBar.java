import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 * The OptionBar class represents a user interface that displays information and user options
 * 
 * @author Ashank Patel
 * @author Harpuneet Tiwana
 * @author Vivian Petrov
 * @author Dorty Makaloni
 * @author Binhang Zhu
 *
 */
public class OptionBar {
	
	JPanel optionPanel;
	Button[] buttonArray;
	JLabel errorDisplay;
	/** 
     * This constructor is the default constructor for the OptionBar class.
     */
	OptionBar(){
		optionPanel = new JPanel();
		optionPanel.setBackground(Color.lightGray);
		optionPanel.setPreferredSize(new Dimension(100,100));
		
	}
	/**
     * This constructor is for the OptionBar class with errors and buttons
     * 
     * @param error initial error information to be displayed.
     * @param numButtons number of buttons to be added to the option bar.
     * @param buttonTexts array of strings representing the text on each button.
     * @param e The ActionListener object to handle button actions.
     * @param errorColor background color for the error display.
     */
	OptionBar(String error, int numButtons, String[] buttonTexts, ActionListener e, Color errorColor){
		// set up JPanel for options bar
		optionPanel = new JPanel();
		optionPanel.setBackground(Color.white);
		optionPanel.setPreferredSize(new Dimension(100,100));
		
		// Set the layout manager and adjust gaps between buttons
        FlowLayout layout = new FlowLayout(FlowLayout.CENTER, 20, 15);
        optionPanel.setLayout(layout);
		
        // set up error display
        errorDisplay = new JLabel(error);
        errorDisplay.setBackground(errorColor);
        errorDisplay.setOpaque(true);
        optionPanel.add(errorDisplay);
        
        // create and add appropriate buttons
	    buttonArray = new Button[numButtons];
	    System.out.println("Button array length in constructor: " + buttonArray.length);
		for (int i=0;i<numButtons;i++) {
			buttonArray[i] = this.addButton(buttonTexts[i], e);
		}		
	}
	/**
     * This method returns the JPanel object representing the option bar
     * 
     * @return optionPanel The JPanel object.
     */	
	// return JPanel object of the option bar
	public JPanel getOptionBar() {
		return optionPanel;
	}
    /**
     * This method adds a new button to the option bar.
     * 
     * @param buttonText text to be displayed on the button
     * @param e The ActionListener object to handle button actions.
     * @return newButton Button object representing the new button.
     */
	// helper method for constructor
	private Button addButton(String buttonText, ActionListener e) {
		Button newButton = new Button(buttonText, e);
		optionPanel.add(newButton.getButton());
		return newButton;
	}
	/**
     * This method adds a new button to the OptionBar
     * 
     * @param buttonText text to be displayed on the button
     * @param e The ActionListener object to handle button actions
     * @return newButton Button object representing the new button
     */
	// add new button to optionPanel
	// may delete as it may be never used -- DON'T FORGET TO ADD BACK BUTTON FOR ERROR CORRECTION / MANUAL ENTER
	public Button addNewButton(String buttonText, ActionListener e) {
	    Button newButton = new Button(buttonText, e);
	    
	    // Create a new array with increased size
	    Button[] tempArr = new Button[buttonArray.length + 1];

	    // Copy elements from the original array to the new array
	    for (int i = 0; i < buttonArray.length; i++) {
	        tempArr[i] = buttonArray[i];
	    }

	    // Add the new button to the end of the new array
	    tempArr[buttonArray.length] = newButton;

	    // Update the buttonArray reference to point to the new array
	    buttonArray = tempArr;
		
	    // Add the new button to the optionPanel
	    optionPanel.add(newButton.getButton());
	    
	    // reset optionPanel
	    optionPanel.revalidate();
	    optionPanel.repaint();
	    
	    return newButton;
	}
	
	/**
     * This method removes current buttons from the OptionBar
     */
    // remove all current buttons from option bar
	public void removeButtons() {
		for (int i=0;i<buttonArray.length;i++) {
			optionPanel.remove(buttonArray[i].getButton());
		}		
		optionPanel.revalidate();
	    optionPanel.repaint();
	}
	 /**
     * This method adds new buttons to OptionBar
     * 
     * @param numButtons The number of buttons to be added
     * @param buttonTexts An array of strings representing the text on each button
     * @param e The ActionListener object to handle button actions
     */
	// add all new buttons to option bar
	public void addButtons(int numButtons, String[] buttonTexts, ActionListener e) {

		buttonArray = new Button[numButtons];
		
		for (int i=0;i<numButtons;i++) {
			buttonArray[i] = this.addButton(buttonTexts[i], e);
		}
		
	}
	/**
     * This method returns the JButton object of a specific button
     * 
     * @param buttonNum The index of the button.
     * @return The JButton object.
     */
	// return JButton object of a specific button
	public JButton getButton(int buttonNum) {
		System.out.println("Button array length: " + buttonArray.length);
		return buttonArray[buttonNum].getButton();
	}
	/**
     * This method updates shows the error information
     * 
     * @param error The new error information to be displayed.
     * @param newErrorColor The background color for the error display.
     */
	// update errorDisplay to show current error
	public void changeErrorDisplay(String error, Color newErrorColor) {
		errorDisplay.setText(error);
		errorDisplay.setBackground(newErrorColor);
	}


}
