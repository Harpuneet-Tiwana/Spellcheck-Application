import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Class representing the help page of the application
 * @author Ashank Patel
 *
 */
public class HelpPage implements ActionListener {

	// Frame for the help page
	Frame Help;

	// Number of buttons on the help page
	int numButtons = 1;

	// Static variables for font settings
	private static int fontSize = 4;
	private static String fontColor = "Black";
	private static String fontStyle = "Arial";

	// Settings manager to handle loading and saving settings
	SettingsManager settingsManager;

	/**
	 * Constructor: This method sets up the help page.
	 */
	HelpPage() {

		// Load settings from a file using the SettingsManager
		settingsManager = SettingsManager.loadSettingsFromFile();

		// Array of button texts for the menu
		String[] menuButtonTexts = {"Back"};

		// Create the main frame for the help page
		Help = new Frame(numButtons, menuButtonTexts, this);

		// Update UI based on user settings
		updateUIBasedOnSettings();
	}

	/**
	 * This method to update UI elements based on user settings.
	 */
	private void updateUIBasedOnSettings() {
		// Retrieve user settings from the settings manager
		fontSize = settingsManager.getFontSize();
		fontStyle = settingsManager.getFontStyle();
		fontColor = settingsManager.getFontColor();

		// Create a label to display help text with user-specific formatting
		JLabel helpText = new JLabel();

		String helpStr = "<html><font size='" + fontSize + "' color='" + fontColor + "' face='" + fontStyle + "'>To detect errors in your file:<br>"
				+ "1. In the Home Page, click Input File button to select your document. <br>"
				+ "   You will be led to the Main Editing Page and the contents of your file will be displayed.<br>"
				+ "2. Click Detect Errors button to determine spelling, miscapitalization, or duplicate word errors in your document<br>"
				+ "   You will be led to the Error Detection Page where you will see your errors highlighted by certain colours (refer to legend at bottom of that page)<br>"
				+ "3. Click Correct Errors button to begin correcting the detected errors. You will be led to the Error Correction Page where you can choose to fix or ignore the errors.<br>"
				+ "4. Click Done button when you have finished making your changes. You will be led back to the Main Editing Page.<br>"
				+ "   You can choose to save a copy of the modified document by clicking Export button. Clicking Done will lead you to the Home Page (be sure to Export before doing so).<br>"
				+ "   Statistics associated with your corrections can be viewed by clicking Metrics button, which will lead you to the Metrics Page<br>"
				+ "   If you wish to correct your document further, you can click Detect Errors again<br>"
				+ "<br>"
				+ "To change settings:"
				+ "1. In the Home Page, click Settings button. You will be led to the Settings Page where you can view and alter the settings.<br>"
				+ "   Please be sure to click Save Changes if you wish to save any changes you have made before returning to the Home Page<br>"
				+ "<br>"
				+ "Which files are accepted?<br>"
				+ "HTML, XML, and txt files are the only file types accepted by this program.<br>"
				+ "</font>"
				+ "</html>";

		helpText.setText(helpStr);

		// Add the label to the main panel of the help page
		Help.getMainPanel().add(helpText, BorderLayout.NORTH);
	}

	/**
	 * ActionListener method to handle button clicks
	 */
	@Override
	public void actionPerformed(ActionEvent e) {

		// Handle back button click
		if (e.getSource() == Help.getMenu().getButton(0)) {
			System.out.println("back button clicked!");

			// Close the current help page and open the home page
			Help.dispose();
			HomePage newWindow = new HomePage();
		}
	}

	/**
	 * Getter method for font size
	 * @return fontSize - the text representing the font size
	 */
	public static int getFontSize() {
		return fontSize;
	}


	/**
	 * Setter method for the font size
	 * @param newFontSize - the number representing the font size
	 */
	public static void setFontSize(int newFontSize) {
		fontSize = newFontSize;
	}

	/**
	 * Getter method for font color
	 * @return the text representing the font color
	 */
	public static String getFontColor() {
		return fontColor;
	}

	/**
	 * Setter method for font color.
	 * @param newFontColor - the text indicating the new font color
	 */
	public static void setFontColor(String newFontColor) {
		fontColor = newFontColor;
	}

	/**
	 * Getter method for font style.
	 * @return the text for the font style
	 */
	public static String getFontStyle() {
		return fontStyle;
	}

	/**
	 * Setter method for font style.
	 * @param newFontStyle - the text indicating new font style
	 */
	public static void setFontStyle(String newFontStyle) {
		fontStyle = newFontStyle;
	}
}
