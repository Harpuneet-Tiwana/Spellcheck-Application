import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.*;
import javax.swing.text.*;
/**
 * This class represents the legend of the application
 * @author Ashank Patel
 * @author Binhang Zhu
 */
public class Legend {

	JPanel panel;
    /**
	 * Constructor: This method sets up the frame for the legend.
	 */
	Legend(){
		
		// set up panel for legened
        panel = new JPanel();
        panel.setLayout(new GridLayout(1, 2, 5, 2)); // 1 row, 2 columns

        // Create panels for colors
        JPanel colorPanel = new JPanel();
        colorPanel.setLayout(new GridLayout(3, 1, 0, 2));
        colorPanel.add(createColoredLabel(Color.RED, "Red"));
        colorPanel.add(createColoredLabel(Color.ORANGE, "Orange"));
        colorPanel.add(createColoredLabel(Color.YELLOW, "Yellow"));

        // Create panel for descriptions
        JPanel descriptionPanel = new JPanel();
        descriptionPanel.setLayout(new GridLayout(3, 1, 0, 2));
        descriptionPanel.add(createDescriptionLabel("Incorrect spelling"));
        descriptionPanel.add(createDescriptionLabel("Incorrect capitalization"));
        descriptionPanel.add(createDescriptionLabel("Duplicate words"));
        
        colorPanel.setBackground(Color.lightGray);
        descriptionPanel.setBackground(Color.lightGray);
        panel.setBackground(Color.lightGray);
        
         // Add a right margin of 200 pixels
        int rightMargin = 200;
        panel.setBorder(new EmptyBorder(0, 0, 0, rightMargin));

        panel.add(colorPanel);
        panel.add(descriptionPanel);
	}
	
	/**
	 * Helper method for constructor
     * @param color - color for label
     * @param text - text for label
     * @return the jlabel
	 */ 
	private static JLabel createColoredLabel(Color color, String text) {
        JLabel label = new JLabel(text);
        label.setOpaque(true);
        label.setBackground(color);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.CENTER);
        return label;
    }
	
	/**
	 * Helper method for constructor
     * @param text - description for label
     * @return the jlabel
	 */ 
    private static JLabel createDescriptionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setHorizontalAlignment(JLabel.LEFT);
        return label;
    }
    /**
	 * Return JPanel object for the legend
     * @return the jpanel
	 */
	public JPanel getLegendPanel() {
		return panel;
	}
	
	
	
	

}
