import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * This class loads the dictionary that will be used to
 * check if the words are spelled correctly.
 * @author Dorty Makaloni
 * @author Binhang Zhu
 */
public class Dictionary {
	
	File d;
	
	private ArrayList<String> dict; // list of words from the dictionary
	
	/**
	 * This method finds the dictionary text file and 
	 * loads it into a String ArrayList <i>dict</i> that will
	 * act as the user dictionary for the program.
	 */
	public Dictionary(){
		d = new File("words.txt");
		Scanner scnr;
		dict = new ArrayList<String>();
		
		try {
			scnr = new Scanner(d);
			while (scnr.hasNextLine()) 
				dict.add(scnr.nextLine());
				

		} catch (FileNotFoundException e1) {
			
			System.out.println("The dictionary file is not found!");
			e1.printStackTrace();
		}
	}
	
	/**
	 * Finds if a specific word is in the dictionary.
	 * @param word - the word to search for
	 * @return true if the word is in the dictionary or false if it is not
	 */
	public boolean searchWord(String word){
		return dict.contains(word);
	}
	
	/**
	 * Inserts new word into the user dictionary
	 * @param word - the word marked as incorrect that the user wants to add to the dictionary
	 * @return true if successful
	 */
	public boolean addWord(String word) {
		dict.add(word);
		Collections.sort(dict);
	       try (BufferedWriter writer = new BufferedWriter(new FileWriter(d))) {
	            for (String outWord : dict) {
	                writer.write(outWord);
	                writer.newLine(); // Add a newline after each word
	            }
	            System.out.println("Dictionary written to file successfully.");
	        } catch (IOException e) {
	            System.out.println("Error writing to file: " + e.getMessage());
	            e.printStackTrace();
	        }
		return true;
	}
	
	/**
	 * Removes a specific word from the user dictionary
	 * @param word - the word that the user wants to remove from the dictionary
	 * @return true if successful
	 */
	public boolean removeWord(String word) {
		dict.remove(word);
		return true;
	}

	/**
	 * Getter method for the dictionary
	 * @return dict
	 */
	public ArrayList<String> getDict(){
		return dict;
	}
	
	/**
	 * Setter method for the dictionary
	 * @param newDict - the updated dictionary
	 */
	public void setDict(ArrayList<String> newDict){
		this.dict = newDict;
	}
}
