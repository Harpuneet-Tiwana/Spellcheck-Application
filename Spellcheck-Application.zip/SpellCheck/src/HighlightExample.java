import java.awt.Color;

import javax.swing.*;
import javax.swing.text.*;

// THIS CLASS IS NOT USED IN THE PROGRAM
public class HighlightExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Highlight Example");
            JTextArea textArea = new JTextArea();
            
            // Set some text in the JTextArea
            textArea.setText("This is a sample text for highlighting.");

            // Create a Highlighter for the JTextArea
            Highlighter highlighter = textArea.getHighlighter();

            // Specify the word to highlight
            String wordToHighlight = "sample";

            // Search for the word in the text
            String text = textArea.getText();
            int index = text.indexOf(wordToHighlight);
            System.out.println(index);
            
            while (index >= 0) {
                try {
                    // Add a highlight for the word
                    highlighter.addHighlight(index, index + wordToHighlight.length(),
                            new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW));
                } catch (BadLocationException e) {
                    e.printStackTrace();
                }

                // Search for the next occurrence of the word
                index = text.indexOf(wordToHighlight, index + 1);
            }

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(new JScrollPane(textArea));
            frame.setSize(400, 300);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}