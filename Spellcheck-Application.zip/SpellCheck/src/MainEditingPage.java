import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.*;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
/**
 * The MainEditingPage class represents the user interface that handles and edits the document
 * This class provides functions for editing, metrics displayed, and error detection
 * @author Ashank Patel
 * @author Harpuneet Tiwana
 * @author Vivian Petrov
 * @author Dorty Makaloni
 * @author Binhang Zhu
 *
 */
public class MainEditingPage implements ActionListener{
	
	Frame Edit;
	int numButtons = 4;
	JTextArea textArea;
	DocumentHandle documentHandle;
	String newText = "";
	boolean firstProcess = true;
	
	/**
	* This method is used to initialize a default MainEditingPage
	*/
	MainEditingPage(){
		
		String [] menuButtonTexts = {"Done", "Detect Errors", "Metrics", "Export"};
		Edit = new Frame(numButtons, menuButtonTexts, this);

	}
	/**
	* This constructor initializes a new MainEditingPage to update existing files
	* 
	* @param newText  new text to update the file
	* @param documentHandle  documentHandle to be usd
	*/
	MainEditingPage(String newText, DocumentHandle documentHandle){
		
		// create the frame and menu for the page
		String [] menuButtonTexts = {"Done", "Detect Errors", "Metrics", "Export"};
		Edit = new Frame(numButtons, menuButtonTexts, this);
		
		// create text area to display document text
		this.newText = newText;
		textArea = new JTextArea();
        textArea.setLineWrap(true);  // Enable line wrap
        textArea.setWrapStyleWord(true);  // Wrap at word boundaries
        textArea.setText(newText);
        
        this.documentHandle = documentHandle;
        
        firstProcess = false;
        
        
        // Set the JTextArea to be non-editable and set its background color (will change later to be white)
        textArea.setEditable(false);
        textArea.setBackground(Color.cyan);
       
        // Add the JTextArea to the mainPanel (i.e. the central panel)
        Edit.getMainPanel().add(textArea, BorderLayout.CENTER);
        
        
		
	}
	/**
	* This is the constructor that initializes a new MainEditingPage for a selected file
	* @param selectedFile - file chosen by user
	*/
	MainEditingPage(File selectedFile) throws IOException{
		
		// create the frame and menu for the page
		String [] menuButtonTexts = {"Done", "Detect Errors", "Metrics", "Export"};
		Edit = new Frame(numButtons, menuButtonTexts, this);
		
		// create text area to display document text
		textArea = new JTextArea();
        textArea.setLineWrap(true);  // Enable line wrap
        textArea.setWrapStyleWord(true);  // Wrap at word boundaries
        
        // create documentHandle object and obtain document text from documentHandle
        try {
        	documentHandle = new DocumentHandle();
            textArea.setText(documentHandle.readFile(selectedFile));
        } catch (IOException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
        
        // Set the JTextArea to be non-editable and set its background color (will change later to be white)
        textArea.setEditable(false);
        textArea.setBackground(Color.cyan);
       
        // Add the JTextArea to the mainPanel (i.e. the central panel)
        Edit.getMainPanel().add(textArea, BorderLayout.CENTER);
	}
	/**
	 * This class returns the frame object associated with this MainEditingPage
	 * @return Edit  the Frame object representing the user interface of this page.
	 */
	public Frame getFrame() {
		return Edit;
	}
	/**
	 * This class returns the JTextArea associated with this MainEditingPage
	 * @return textArea  the JText object used for displaying and editing file text
	 */
	public JTextArea getTextArea() {
		return textArea;
	}
	/**
	* This method handles actions performed on the buttons of the Main Editing Page and performs corresponding actions
	* @param e an ActionEvent that represents an action done by the user
	*/
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// done button
		if (e.getSource()==Edit.getMenu().getButton(0)) {
			
			// go back to Home Page
			Edit.dispose();
			HomePage newWindow = new HomePage();
		}
		// detect errors button
		else if (e.getSource()==Edit.getMenu().getButton(1)) {
			
			Edit.dispose();
			
			if (firstProcess == true) {
				ErrorDetectionPage newWindow = new ErrorDetectionPage(documentHandle, textArea.getText());
			}
			else if (firstProcess == false) {
				DocumentHandle newDocumentHandle = new DocumentHandle();
				newDocumentHandle.updateDocumentWords(newText);
				ErrorDetectionPage newWindow = new ErrorDetectionPage(newDocumentHandle, textArea.getText());
			}			
			
			
		}
		// metrics button
		else if (e.getSource()==Edit.getMenu().getButton(2)) {
			
			Edit.dispose();
			MetricsPage newWindow = new MetricsPage(documentHandle, textArea.getText());
		}
		// export/save file
		else if (e.getSource()==Edit.getMenu().getButton(3)) {
			
			
			JFileChooser fileChooser = new JFileChooser();
			int response = fileChooser.showOpenDialog(null);

			// If a file is selected, create a new MainEditingPage with the selected file
			if (response == JFileChooser.APPROVE_OPTION) {
				File selectedFile = new File(fileChooser.getSelectedFile().getAbsolutePath());
				
				try {
					documentHandle.writeFile(selectedFile, textArea.getText());
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
				
			}

		}
		

		
	}
}
