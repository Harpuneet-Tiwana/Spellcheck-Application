import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
/**
 * This class provides the functions for the
 * buttons used in the frames.
 * @author Ashank Patel
 */
public class Button {
	
	JButton button;
	/**
	 * Constructor: This method sets up the button(s)
	 * that are in the frame.
	 */
	Button(){
		button = new JButton();
		button.setPreferredSize(new Dimension(100,50));
		button.setBackground(Color.cyan);
		
	}
	/**
	 * Constructor: 
	 * It is an overloading method for whenever the 
	 * button text and the ActionListener are provided.
	 * @param text - the text displayed on the button
	 * @param e - the ActionListener object
	 */
	Button(String text, ActionListener e){
		button = new JButton();
		button.setPreferredSize(new Dimension(140,70));
		button.setBackground(Color.cyan);
		button.setText(text);
		button.addActionListener(e);
		button.setFocusable(false);
		
	}
	/**
	 * This method sets the text of the button
	 * @param the text displayed on the button
	 */
	public void setText(String text){
		button.setText(text);
	}
	/**
	 * Getter method for the button
	 * @return the JButton object
	 */
	public JButton getButton() {
		return button;
	}
	/**
	 * This method adds the actionListener to the button.
	 * @param e - ActionListener object
	 */
	public void addListener(ActionListener e) {
		button.addActionListener(e);
	}

}
