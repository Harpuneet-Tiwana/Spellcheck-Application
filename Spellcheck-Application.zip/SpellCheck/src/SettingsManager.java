import java.io.*;

// Serializable class to manage application settings
public class SettingsManager implements Serializable {

    // Serial version UID for serialization
    private static final long serialVersionUID = 1L;

    // Fields to store user settings
    private String userName;
    private int fontSize;
    private String fontColor;
    private String fontStyle;

    // Default constructor initializes default values
    public SettingsManager() {
        this.userName = "DefaultUser";
        this.fontSize = 4;
        this.fontColor = "Black";
        this.fontStyle = "Arial";
    }

    // Getters and Setters for user settings

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getFontSize() {
        return fontSize;
    }

    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public String getFontStyle() {
        return fontStyle;
    }

    public void setFontStyle(String fontStyle) {
        this.fontStyle = fontStyle;
    }

    // Save settings to a file using object serialization
    public void saveSettingsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("settings.dat"))) {
            oos.writeObject(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load settings from a file using object deserialization
    public static SettingsManager loadSettingsFromFile() {
        SettingsManager settingsManager = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("settings.dat"))) {
            settingsManager = (SettingsManager) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // Handle file not found or other exceptions
            // Create a new instance if the file is not found (for simplicity)
            settingsManager = new SettingsManager();
        }
        return settingsManager;
    }
}
