import java.util.ArrayList;

/**
 * This class suggests corrections for certain errors.
 * @author Dorty Makaloni
 * @author Binhang Zhu
 */

public class ErrorCorrection{
	private ArrayList<Integer> errortypes;
	private ArrayList<Integer> errorindices;
	DocumentHandle dhandle;
	Dictionary dictionary;
	private ArrayList<String> dict;
	/**
	 * Constructor: This method creates instances of the DocumentHandle and Dictionary objects.
	 * It also creates the dictionary for reference into a list
	 * @param dhandle - the DocumentHandle object
	 * @param dictionary - the Dictionary object
	 */
	public ErrorCorrection(DocumentHandle dhandle, Dictionary dictionary) {
		this.dhandle = dhandle;
		this.dictionary = dictionary;
		dict = dictionary.getDict(); // dictionary for reference
	}
	
	/**
	 * This methods provides misspelling corrections for the word
	 * @param word - misspelled word to be corrected
	 * @return list of all suggested spelling corrections
	 */
	public ArrayList<String> fixMisspelling(String word) {
		
		ArrayList<String> misspellCorr = new ArrayList<String>(); // Suggested corrections for misspelling
		
		// All the methods for misspelling corrections are added to the misspellCorr list
		ArrayList<String> corrWithSub = correctionWithSubstitution(word, dict);
		for (int i = 0; i < corrWithSub.size(); i++) {
			if (!misspellCorr.contains(corrWithSub.get(i)))
				misspellCorr.add(corrWithSub.get(i));
		}
		ArrayList<String> corrWithOmis = correctionWithOmission(word, dict);
		for (int i = 0; i < corrWithOmis.size(); i++) {
			if (!misspellCorr.contains(corrWithOmis.get(i)))
				misspellCorr.add(corrWithOmis.get(i));
		}
		ArrayList<String> corrWithIns = correctionWithInsertion(word, dict);
		for (int i = 0; i < corrWithIns.size(); i++) {
			if (!misspellCorr.contains(corrWithIns.get(i)))
				misspellCorr.add(corrWithIns.get(i));
		}
		ArrayList<String> corrWithRev = correctionWithReversal(word, dict);
		for (int i = 0; i < corrWithRev.size(); i++) {
			if (!misspellCorr.contains(corrWithRev.get(i)))
				misspellCorr.add(corrWithRev.get(i));
		}
		
		return misspellCorr;
	}
	
	/**
	 * This methods corrects the capitalization of the word.
	 * @param word - the miscapitalized word
	 * @return the word with proper capitalization
	 */
	public String fixCapitalization(String word) {
		String cap = "";
		if (Character.isLowerCase(word.charAt(0)))
			cap = word.substring(0, 1).toUpperCase() + word.substring(1);
		else
			cap = word.substring(0, 1).toLowerCase() + word.substring(1);
		
		return cap;
	}
	
	/**
	 * This methods finds and removes the duplicated word.
	 * @param word - the duplicated word
	 */
	public void fixDuplicate(String word) {
		ArrayList<String> docWords = dhandle.getWords();
		for (int i = 0; i < docWords.size(); i++) {
			if (docWords.get(i) == word && docWords.get(i) == docWords.get(i + 1)) {
				docWords.remove(i);
				break;
			}
		}
		//dhandle.setWords(docWords);
	}
	
	/** 
	 * fixMispelling helper method: takes in a string word and tries to correct the 
	 * spelling by substituting letters and checks if the resulting new word is in the dictionary. 
	 * @param word - the misspelled word
	 * @param dict - the dictionary used as reference
	 * @return list of suggested corrections using substitution 
	 */
	private ArrayList<String> correctionWithSubstitution(String word, ArrayList<String> dict) {
		String newWord = "";
		ArrayList<String> corrList = new ArrayList<String>();
		
		// Each character of the word is substituted with the 25 other letters
		for (int i = 0; i < word.length(); i++) {
			for (char j = 'a'; j <= 'z'; j++) {
				// Skip the letter if it is the same as the original
				if (word.charAt(i) == j)
					continue;
				else {
					// A new word is formed from concatenating the word's substring
					// up to but excluding the letter, then the substituted letter,
					// then the rest of the word as a substring.
					newWord = word.substring(0,i) + j + word.substring(i + 1);
					if (dict.contains(newWord))
						corrList.add(newWord);
				}
			}
		}

		return corrList;
	}

	/**
	 * fixMispelling helper method: omits (in turn, one by one) a single character in the 
	 * misspelled word and checks if the resulting new word is in the dictionary.
	 * @param word - the misspelled word
	 * @param dict - the dictionary used as reference
	 * @return list of suggested corrections using omission
	 */
	private ArrayList<String> correctionWithOmission(String word, ArrayList<String> dict) {
		String newWord = "";
		ArrayList<String> corrList = new ArrayList<String>();

		// newWord is formed from concatenating the word's substring
		// up to but excluding the letter and rest of the word as a substring.
		for (int i = 0; i < word.length(); i++) {
			newWord = word.substring(0,i) + word.substring(i + 1);
			if (dict.contains(newWord))
				corrList.add(newWord);
		}

		return corrList;
	}

	/**
	 * fixMispelling helper method: inserts a letter in the misspelled word
	 * and checks if the resulting new word is in the dictionary.
	 * @param word - the misspelled word
	 * @param dict - the dictionary used as reference
	 * @return ArrayList of suggested corrections using insertion
	 */
	private ArrayList<String> correctionWithInsertion(String word, ArrayList<String> dict) {
		String newWord = "";
		ArrayList<String> corrList = new ArrayList<String>();
		
		// A new word is formed by inserting a letter at the
		// word's beginning, end, and between each pair of chars
		for (int i = 0; i < word.length() + 1; i++) {
			for (char j = 'a'; j <= 'z'; j++) {
				newWord = word.substring(0, i) + j + word.substring(i);
				// If the new word is in the dictionary, add the word to
				// the list
				if (dict.contains(newWord)) {
					corrList.add(newWord);
				}
			}
		}

		return corrList;
	}

	/**
	 * fixMispelling helper method: swaps every pair of adjacent characters in
	 * the misspelled word and checks if the resulting new word is in the dictionary.
	 * @param word - the misspelled word
	 * @param dict - the dictionary used as reference
	 * @return list of suggested corrections using reversal
	 */
	private ArrayList<String> correctionWithReversal(String word, ArrayList<String> dict) {
		String newWord = "";
		ArrayList<String> corrList = new ArrayList<String>();
		
		for (int i = 0; i < word.length() - 1; i++) {
			char ch1 = word.charAt(i); // ch1 (first character)
			char ch2 = word.charAt(i + 1); // ch2 (second character)

			/**
			 * The new word is assigned the word up to but excluding first character
			 * followed by the word's second character, then the word's first character,
			 * then the rest of the word starting from after the word's second character.
			 */
			newWord = word.substring(0, i) + ch2 + ch1 + word.substring(i + 2);

			if (dict.contains(newWord))
				corrList.add(newWord);
		}

		return corrList;
	}

	/**
	 * helper method: obtains two arrays, one containing
	 * the types of errors and the other containing the indices of where the error occurs.
	 * @param word - the misspelled word
	 */
	private void getErrorInfo() {
		errortypes = dhandle.getErrorType();
		errorindices = dhandle.getErrorIndex();
	}

	/**
	 * helper method: Given the type of error and the index at where it occurs,
	 * call the appropriate method to fix that type of error.
	 * @param errorType - the type of error
	 * @param errorIndex - the index where the error occurs
	 */
	private void correctionHandle(int errorType, int errorIndex) {
		if (errorType == 1) {
			fixMisspelling(dhandle.searchWord(errorIndex));
		}else if (errorType == 2) {
			fixCapitalization(dhandle.searchWord(errorIndex));
		} else if (errorType == 3) {
			fixDuplicate(dhandle.searchWord(errorIndex));
		}
	}

	/**
	 * helper method: Allows for user to input a word manually.
	 * @param word - the word that was inputted by the user
	 * @return returns the word that was inputted
	 */
	private String enterManualWord(String word) {
		return word;
	}

	/**
	 * helper method: Replaces the incorrect word at a given index 
	 * with the correct one.
	 * @param index - the index of the word to be replaced
	 * @param correctWord - the correct word that will replace the incorrect one
	 */
	private void fixDocWord(int index, String correctWord) {
		dhandle.fixWord(index, correctWord); 
	}

	/**
	 * This method uses the helper method to retrieve the indices and types of errors.
	 * Then it passes each pair of index and error type to the correctionHandle method
	 * where it will be dealt with.
	 */
	public void fixErrors() {
		getErrorInfo();
		for (int i = 0; i < errortypes.size(); i++) {
			int type = errortypes.get(i);
			int index = errorindices.get(i);
			correctionHandle(type, index);
		}
	}


}